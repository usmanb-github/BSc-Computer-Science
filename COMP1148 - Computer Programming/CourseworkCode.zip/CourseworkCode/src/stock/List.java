package stock;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class List extends JFrame {
    //creating table
    JTable list = new JTable();

    public List() {
        setLayout(new BorderLayout());
        setSize(700, 200);
        setTitle("List");

        JPanel top = new JPanel();
        JLabel label = new JLabel("Here is the default stock: -");
        label.setFont(new Font("Calibri", Font.PLAIN, 16));
        top.add(label);
        add("North", top);
        //list
        String[] column = {"Stock", "Quantity", "Price"};
        //details within box
        Object[][] data = {
            {"01 - Towel", "£5.00", "10"},
            {"02 - Playstation 4", "£250.00", "20"},
            {"03 - Fifa 16", "£25.00", "30"},};
        list = new JTable(data, column);
        //puts all data within table
        list.setPreferredScrollableViewportSize(new Dimension(150, 20));
        list.setFillsViewportHeight(false);
        //sets details of table
        JScrollPane scroll = new JScrollPane(list);
        add(scroll);
        //adds table to panel
        setResizable(false);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        System.exit(0);
    }
}
