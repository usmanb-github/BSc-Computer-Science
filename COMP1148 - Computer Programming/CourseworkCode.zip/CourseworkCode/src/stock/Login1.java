package stock;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Login1 extends JFrame implements ActionListener {

    JTextField username = new JTextField(7);
    JPasswordField password = new JPasswordField(7);
    JButton login = new JButton("Login");

    public Login1() {
        setLayout(new BorderLayout());
        setSize(420, 70);
        setTitle("Login");
        JPanel top = new JPanel();
        top.add(new JLabel("Username"));
        top.add(username);
        top.add(new JLabel("Password"));
        top.add(password);
        top.add(login);
        login.addActionListener(this);
        add("North", top);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == login) {
            try {
                //details below connected to database
                String host = "jdbc:derby://localhost:1527/UserDB";
                String j = "use";
                String p = "pass";
                Connection con = DriverManager.getConnection(host, j, p);
                Statement stmt = con.createStatement();
                String SQL = "SELECT * FROM USE.LOGIN";
                ResultSet rs = stmt.executeQuery(SQL);

                String z = username.getText();
                String i = password.getText();

                rs.next();
                String s = rs.getString("username");
                String w = rs.getString("password");
                if (z.matches(s) && i.matches(w)) {
                    display("Login Successful!");
                    TwoButtons update = new TwoButtons();
                    setVisible(false);
                } else {
                    display("Wrong details!");
                    username.setText("");
                    password.setText("");
                }
            } catch (SQLException evt) {
                display(evt.getMessage());
            }
        }
    }

    private static void display(String s) {
        JOptionPane.showMessageDialog(null, s);
        //uses method to shorten code
    }
    
}
