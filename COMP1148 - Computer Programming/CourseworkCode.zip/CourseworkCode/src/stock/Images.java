package stock;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Images extends JFrame
        implements ActionListener {
    private MyCanvas canvas = new MyCanvas();
    
    public Images() {
        setLayout(new BorderLayout());
        setSize(500, 300);
        setTitle("Images");
        add("Center", canvas);
        canvas.setBackground(Color.gray);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // add your event handling code here
    }

    private class MyCanvas extends Canvas {

        @Override
        public void paint(Graphics g) {
            Image towels =
                    new ImageIcon("Images/towels.jpg").getImage();
            Image playstation =
                    new ImageIcon("Images/playstationfour.jpg").getImage();
            
            g.drawImage(towels, 330, 10, this);
            g.drawImage(playstation, 200, 60, this);
        }
    }
}
