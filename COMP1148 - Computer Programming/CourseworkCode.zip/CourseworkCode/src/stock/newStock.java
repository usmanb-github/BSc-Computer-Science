package stock;
//import java.awt.*;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author ub2232e
 */
public class newStock extends JFrame
        implements ActionListener {

    JTextField jKey = new JTextField(7);
    JTextField jName = new JTextField(7);
    JTextField jPrice = new JTextField(7);
    JTextField jQuantity = new JTextField(7);
    JButton jButton = new JButton("Add");
   
    public newStock() {
        setLayout(new BorderLayout());
        setBounds(100, 100, 700, 80);
        setTitle("Adding new Stock");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBackground(Color.blue);
        JPanel top = new JPanel();
        top.add(new JLabel("Key:"));
        top.add(jKey);
        top.add(new JLabel("Name:"));
        top.add(jName);
        top.add(new JLabel("Price:"));
        top.add(jPrice);
        top.add(new JLabel("Quantity:"));
        top.add(jQuantity);
        top.add(jButton);
        jButton.addActionListener(this);
        add("North", top);

        setResizable(false);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String keyStr = jKey.getText();
        String nameStr = jName.getText();
        double priceDouble = Double.parseDouble(jPrice.getText());
        int quantityInt = Integer.parseInt(jQuantity.getText());

        if (e.getSource() == jButton) {
            try {
                String host = "jdbc:derby://localhost:1527/UserDB";
                String j = "use";
                String p = "pass";

                Connection con = DriverManager.getConnection(host, j, p);
                PreparedStatement stmt = (PreparedStatement) con.prepareStatement("INSERT INTO STOCK(stockKey, stockName, stockPrice, stockQuantity) "
                        + "VALUES(?,?,?,?)");
                stmt.setString(1, keyStr);
                stmt.setString(2, nameStr);
                stmt.setDouble(3, priceDouble);
                stmt.setInt(4, quantityInt);
                
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(null, "You have successfully added a new item");
                
                jKey.setText("");
                jName.setText("");
                jPrice.setText("");
                jQuantity.setText("");
                
            } catch (Exception ea) {
                JOptionPane.showMessageDialog(null, ea);
            }
        }
    }
}
