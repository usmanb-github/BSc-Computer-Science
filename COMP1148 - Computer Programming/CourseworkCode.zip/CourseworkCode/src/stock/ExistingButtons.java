package stock;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ExistingButtons extends JFrame implements ActionListener {
    
//creating buttons
    JButton quantity = new JButton("Quantity");
    JButton price = new JButton("Price");
    JButton delete = new JButton("Delete");

    public ExistingButtons() {
        setLayout(new BorderLayout());
        setSize(400, 100);
        JPanel top = new JPanel();
        top.add(new JLabel("Select an option by clicking one of the buttons below:"));
        add("North", top);

        JPanel bottom = new JPanel();
        //adding buttons on bottom panel
        bottom.add(quantity);
        quantity.addActionListener(this);
        bottom.add(price);
        price.addActionListener(this);
        bottom.add(delete);
        delete.addActionListener(this);
        add("South", bottom);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        if (e.getSource() == quantity) {
            UpdateStock update = new UpdateStock();
            setVisible(false);
        } else if (e.getSource() == price) {
            UpdatePrice update = new UpdatePrice();
            setVisible(false);
        } else if (e.getSource() == delete) {
            UpdateDelete d = new UpdateDelete();
            setVisible(false);
        }
        //once clicked, displays different classes
    }
}