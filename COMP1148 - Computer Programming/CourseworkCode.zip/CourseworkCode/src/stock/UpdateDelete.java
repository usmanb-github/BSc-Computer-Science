package stock;
//import java.awt.*;

import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.event.ActionEvent;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import org.apache.derby.drda.NetworkServerControl;

/**
 *
 * @author ub2232e
 */
public class UpdateDelete extends JFrame
        implements ActionListener {

    JTextField stockNo = new JTextField(7);
    JButton checkBtn = new JButton("Check Stock");
    JButton deleteBtn = new JButton("Delete");
    DecimalFormat pounds = new DecimalFormat("£#,##0.00");
    JTextArea information = new JTextArea(3, 25);
    private static Connection connection;
    private static Statement stmt;

    static {
        // standard code to open a connection and statement to an Access database
        try {
            NetworkServerControl server = new NetworkServerControl();
            server.start(null);
            // Load JDBC driver
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
            //Establish a connection
            String sourceURL = "jdbc:derby://localhost:1527/"
                    + new File("UserDB").getAbsolutePath() + ";";
            Connection UserDB = DriverManager.getConnection(sourceURL, "use", "pass");
            stmt = UserDB.createStatement();
        } catch (ClassNotFoundException cnfe) {
            System.out.println(cnfe);
        } catch (SQLException sqle) {
            System.out.println(sqle);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public UpdateDelete() {
        setLayout(new BorderLayout());
        setBounds(200, 200, 500, 150);
        setTitle("Update Delete");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel top = new JPanel();
        top.add(new JLabel("Enter Stock Number:"));
        top.add(stockNo);
        top.add(checkBtn);
        checkBtn.addActionListener(this);        
        add("North", top);
        JPanel middle = new JPanel();
        middle.add(information);
        add("Center", middle);
        JPanel bottom = new JPanel();
        bottom.add(deleteBtn);
        deleteBtn.addActionListener(this);
        add("South", bottom);

        setResizable(false);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String key = stockNo.getText();
        String name = StockData.getName(key);
        if (name == null) {
            information.setText("No such item in stock");
        } else {
            information.setText(name);
            information.append("\nPrice: " + pounds.format(StockData.getPrice(key)));
            information.append("\nQuantity: " + StockData.getQuantity(key));
        }

        if (e.getSource() == deleteBtn) {
            if (name != null) {
                int confirmOption =  JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this item?");
                if (confirmOption == JOptionPane.YES_OPTION) {
                    try {
                        String sql = "DELETE FROM Stock WHERE stockKey = '" + key + "'";
                        stmt.execute(sql);
                        JOptionPane.showMessageDialog(null, "You have successfully deleted this item.");
                    } catch (Exception ea) {
                        System.out.println(ea);
                    }
                }
                if (confirmOption == JOptionPane.NO_OPTION) {
                    JOptionPane.showMessageDialog(null, "Please try again to attempt to delete this item from stock");
                }
            }
        }
    }
}