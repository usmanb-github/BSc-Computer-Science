package stock;

import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Master extends JFrame implements ActionListener {

    JButton check = new JButton("Check Item");
    JButton list = new JButton("Stock List");
    JButton purchase = new JButton("Purchase Item");
    JButton stock = new JButton("Update Stock");
    JButton quit = new JButton("Exit");
    JButton help = new JButton("Help and Support");

    public static void main(String[] args) {
        Master master = new Master();
    }

    public Master() {
        setLayout(new BorderLayout());
        setSize(700, 100);
        setTitle("Master");
        JPanel top = new JPanel();
        top.add(new JLabel("Select an option by clicking one of the buttons below"));
        add("North", top);

        JPanel bottom = new JPanel();
        bottom.add(list);
        list.addActionListener(this);
        bottom.add(check);
        check.addActionListener(this);
        bottom.add(purchase);
        purchase.addActionListener(this);
        bottom.add(stock);
        stock.addActionListener(this);
        bottom.add(help);
        help.addActionListener(this);
        bottom.add(quit);
        quit.addActionListener(this);
        add("South", bottom);

        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == check) {
            CheckStock checkStock = new CheckStock();
        } else if (e.getSource() == purchase) {
            PurchaseItem purchaseItem = new PurchaseItem();
        } else if (e.getSource() == stock) {
            Login1 Login = new Login1();
        } else if (e.getSource() == list) {
            List list = new List();
        } else if (e.getSource() == help) {
            if (e.getSource() == help) {
                if (Desktop.isDesktopSupported()) {
                    Desktop desktop = Desktop.getDesktop();

                    try {
                        desktop.edit(new File("Guide.txt"));
                    } catch (Exception ex) {
                        System.out.println(ex);
                    }
                } else {
                    System.out.println("Desktop is not supported");
                }
            }
        } else if (e.getSource() == quit) {
            System.exit(0);
        }
    }
}
