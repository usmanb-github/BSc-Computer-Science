﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace WindowsFormsApplication7
{
    public partial class Form1 : Form
    {

        Socket m_ClientSocket;
        System.Net.IPEndPoint m_remoteEndPoint;
        private static System.Windows.Forms.Timer m_CommunicationActivity_Timer;
        string oppAnswer;
        string youranswer;

        public Form1()
        {
            InitializeComponent();

            m_CommunicationActivity_Timer = new System.Windows.Forms.Timer(); // Check for communication activity on Non-Blocking sockets every 200ms
            m_CommunicationActivity_Timer.Tick += new EventHandler(OnTimedEvent_PeriodicCommunicationActivityCheck); // Set event handler method for timer
            m_CommunicationActivity_Timer.Interval = 100;  // Timer interval is 1/10 second
            m_CommunicationActivity_Timer.Enabled = false;
            CloseConnection_button.Enabled = false;
            greenPictureBox.Enabled = false;
            bluePictureBox.Enabled = false;
            redPictureBox.Enabled = false;
            chosenpictureBox.Enabled = false;
            guessedpicturebox.Enabled = false;
            CloseConnection_button.Text = "Close Connection";
            string szLocalIPAddress = GetLocalIPAddress_AsString(); // Get local IP address as a default value
            IP_Address_textBox.Text = szLocalIPAddress;             // Place local IP address in IP address field
            SendPort_textBox.Text = "8000"; // Default port number

        }

        private string GetLocalIPAddress_AsString()
        {
            string szHost = Dns.GetHostName();
            string szLocalIPaddress = "127.0.0.1";  // Default is local loopback address
            IPHostEntry IPHost = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress IP in IPHost.AddressList)
            {
                if (IP.AddressFamily == AddressFamily.InterNetwork) // Match only the IPv4 address
                {
                    szLocalIPaddress = IP.ToString();
                    break;
                }
            }
            return szLocalIPaddress;
        }


        private void btnClear_Click(object sender, EventArgs e)
        {
            guessedpicturebox.Image = null;
            chosenpictureBox.Image = null;
            panelPlayer.BackColor = Color.LightGray;
            panelComputer.BackColor = Color.LightGray;
        }


        private void Connect_button_Click(object sender, EventArgs e)
        {
            try
            {
                // Create the socket, for TCP use
                m_ClientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                m_ClientSocket.Blocking = true; // Socket operates in Blocking mode initially
            }
            catch // Handle any exceptions
            {
                Close_Socket_and_Exit();
            }
            try
            {
                // Get the IP address from the appropriate text box
                String szIPAddress = IP_Address_textBox.Text;
                System.Net.IPAddress DestinationIPAddress = System.Net.IPAddress.Parse(szIPAddress);

                // Get the Port number from the appropriate text box
                String szPort = SendPort_textBox.Text;
                int iPort = System.Convert.ToInt16(szPort, 10);

                // Combine Address and Port to create an Endpoint
                m_remoteEndPoint = new System.Net.IPEndPoint(DestinationIPAddress, iPort);

                m_ClientSocket.Connect(m_remoteEndPoint);
                m_ClientSocket.Blocking = false;    // Socket is now switched to Non-Blocking mode for send/ receive activities
                Connect_button.Text = "Connected";
                Connect_button.Enabled = false;
                IP_Address_textBox.Enabled = false;
                SendPort_textBox.Enabled = false;
                CloseConnection_button.Enabled = true;
                greenPictureBox.Enabled = true;
                bluePictureBox.Enabled = true;
                redPictureBox.Enabled = true;
                chosenpictureBox.Enabled = true;
                guessedpicturebox.Enabled = true;
                CloseConnection_button.Text = "Close Connection";
                m_CommunicationActivity_Timer.Start();  // Start the timer to perform periodic checking for received messages   
            }
            catch // Catch all exceptions
            {   // If an exception occurs, display an error message
                Connect_button.Text = "(Connect attempt failed)\nRetry Connect";
            }
        }

        private void OnTimedEvent_PeriodicCommunicationActivityCheck(Object myObject, EventArgs myEventArgs)
        {   // Periodic check whether a message has been received    
            try
            {
                EndPoint RemoteEndPoint = (EndPoint)m_remoteEndPoint;
                byte[] ReceiveBuffer = new byte[1024];
                int iReceiveByteCount;
                iReceiveByteCount = m_ClientSocket.ReceiveFrom(ReceiveBuffer, ref RemoteEndPoint);

                string szReceivedMessage;
                if (0 < iReceiveByteCount)
                {   // Copy the number of bytes received, from the message buffer to the text control
                    szReceivedMessage = Encoding.ASCII.GetString(ReceiveBuffer, 0, iReceiveByteCount);
                    oppAnswer = szReceivedMessage;


                    if (youranswer == oppAnswer)
                    {
                        if (youranswer == "Green")
                        {
                            MessageBox.Show("Player Two guessed it correctly");
                            guessedpicturebox.Image = greenPictureBox.Image;
                            listBox1.Items.Add("Player Two chosen green, its correct");
                        }
                        else if (youranswer == "Blue")
                        {
                            MessageBox.Show("Player Two guessed it correctly");
                            guessedpicturebox.Image = bluePictureBox.Image;
                            listBox1.Items.Add("Player Two chosen Blue, its correct");

                        }
                        else if (youranswer == "Red")
                        {
                            MessageBox.Show("Player Two guessed it correctly");
                            guessedpicturebox.Image = redPictureBox.Image;
                            listBox1.Items.Add("Player Two chosen Red, its correct");


                        }
                    }
                    //lost
                    else if (youranswer == "Red" && oppAnswer == "Green")
                    {
                        MessageBox.Show("Player Two guessed it incorrectly");
                        guessedpicturebox.Image = greenPictureBox.Image;
                        listBox1.Items.Add("Player Two chosen incorrect");


                    }
                    else if (youranswer == "Red" && oppAnswer == "Blue")
                    {
                        MessageBox.Show("Player Two guessed it incorrectly");
                        guessedpicturebox.Image = bluePictureBox.Image;
                        listBox1.Items.Add("Player Two chosen incorrect");

                    }
                    else if (youranswer == "Blue" && oppAnswer == "Red")
                    {
                        MessageBox.Show("Player Two guessed it incorrectly");
                        guessedpicturebox.Image = redPictureBox.Image;
                        listBox1.Items.Add("Player Two chosen incorrect");

                    }
                    else if (youranswer == "Blue" && oppAnswer == "Green")
                    {
                        MessageBox.Show("Player Two guessed it incorrectly");
                        guessedpicturebox.Image = greenPictureBox.Image;
                        listBox1.Items.Add("Player Two chosen incorrect");

                    }
                    else if (youranswer == "Green" && oppAnswer == "Red")
                    {
                        MessageBox.Show("Player Two guessed it incorrectly");
                        guessedpicturebox.Image = redPictureBox.Image;
                        listBox1.Items.Add("Player Two chosen incorrect");

                    }
                    else if (youranswer == "Green" && oppAnswer == "Blue")
                    {
                        MessageBox.Show("Player Two guessed it incorrectly");
                        guessedpicturebox.Image = bluePictureBox.Image;
                        listBox1.Items.Add("Player Two chosen incorrect");

                    }
                }
            }
            catch // Silently handle any exceptions
            {
            }
        }
   
        private void Close_Socket_and_Exit()
        {
            try
            {
                m_ClientSocket.Shutdown(SocketShutdown.Both);
            }
            catch // Silently handle any exceptions
            {
            }
            try
            {
                m_ClientSocket.Close();
            }
            catch // Silently handle any exceptions
            {
            }
            this.Close();
        }

        private void CloseConnection_button_Click(object sender, EventArgs e)
        {
            try
            {
                String szData = "QuitConnection"; // Special code to signal 'close connection' to the server
                // This ensures that the server is aware the Client wants to close the connection
                // (TCP should otherwise automatically detect disconnection, but this approach ensures a clean disconnect)
                byte[] byData = System.Text.Encoding.ASCII.GetBytes(szData);
                m_ClientSocket.Send(byData, SocketFlags.None);
                m_ClientSocket.Shutdown(SocketShutdown.Both);
                m_ClientSocket.Close();
                CloseConnection_button.Enabled = false;
                CloseConnection_button.Text = "Connection Closed";
                Connect_button.Enabled = true;
                Connect_button.Text = "Connect";
            }
            catch // Silently handle any exceptions
            {
            }
        }

        private void redPictureBox_Click_1(object sender, EventArgs e)
        {

            chosenpictureBox.Image = redPictureBox.Image;

            try
            {
                String szData = "Red";
                youranswer = szData;

                byte[] byData = System.Text.Encoding.ASCII.GetBytes(szData);
                m_ClientSocket.Send(byData, SocketFlags.None);
            }
            catch // Silently handle any exceptions
            {
            }
        }

        private void bluePictureBox_Click_1(object sender, EventArgs e)
        {
           
            chosenpictureBox.Image = bluePictureBox.Image;

            try
            {
                String szData = "Blue";
                youranswer = szData;

                byte[] byData = System.Text.Encoding.ASCII.GetBytes(szData);
                m_ClientSocket.Send(byData, SocketFlags.None);
            }
            catch // Silently handle any exceptions
            {
            }
        }

        private void greenPictureBox_Click_1(object sender, EventArgs e)
        {
       
            chosenpictureBox.Image = greenPictureBox.Image;

            try
            {
                String szData = "Green";
                youranswer = szData;
                byte[] byData = System.Text.Encoding.ASCII.GetBytes(szData);
                m_ClientSocket.Send(byData, SocketFlags.None);
            }
            catch // Silently handle any exceptions
            {
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            chosenpictureBox.Image = null;
            guessedpicturebox.Image = null;
            listBox1.Items.Clear();
        }
    }
}
