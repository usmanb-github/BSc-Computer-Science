﻿namespace WindowsFormsApplication7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.CloseConnection_button = new System.Windows.Forms.Button();
            this.Connect_button = new System.Windows.Forms.Button();
            this.SendPort_textBox = new System.Windows.Forms.TextBox();
            this.IP_Address_textBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.redPictureBox = new System.Windows.Forms.PictureBox();
            this.bluePictureBox = new System.Windows.Forms.PictureBox();
            this.greenPictureBox = new System.Windows.Forms.PictureBox();
            this.chosenpictureBox = new System.Windows.Forms.PictureBox();
            this.guessedpicturebox = new System.Windows.Forms.PictureBox();
            this.panelPlayer = new System.Windows.Forms.Panel();
            this.panelComputer = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.redPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bluePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.greenPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chosenpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guessedpicturebox)).BeginInit();
            this.panelPlayer.SuspendLayout();
            this.panelComputer.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(64, 149);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Green";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(237, 149);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Blue";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(410, 149);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Red";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(37, 310);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Chosen your colour";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(382, 310);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Guessed Colour";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.CloseConnection_button);
            this.groupBox1.Controls.Add(this.Connect_button);
            this.groupBox1.Controls.Add(this.SendPort_textBox);
            this.groupBox1.Controls.Add(this.IP_Address_textBox);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Location = new System.Drawing.Point(134, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(294, 129);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Communication";
            // 
            // CloseConnection_button
            // 
            this.CloseConnection_button.Location = new System.Drawing.Point(166, 85);
            this.CloseConnection_button.Name = "CloseConnection_button";
            this.CloseConnection_button.Size = new System.Drawing.Size(109, 37);
            this.CloseConnection_button.TabIndex = 10;
            this.CloseConnection_button.Text = "Close Connection";
            this.CloseConnection_button.UseVisualStyleBackColor = true;
            this.CloseConnection_button.Click += new System.EventHandler(this.CloseConnection_button_Click);
            // 
            // Connect_button
            // 
            this.Connect_button.Location = new System.Drawing.Point(19, 85);
            this.Connect_button.Name = "Connect_button";
            this.Connect_button.Size = new System.Drawing.Size(141, 37);
            this.Connect_button.TabIndex = 9;
            this.Connect_button.Text = "Connect";
            this.Connect_button.UseVisualStyleBackColor = true;
            this.Connect_button.Click += new System.EventHandler(this.Connect_button_Click);
            // 
            // SendPort_textBox
            // 
            this.SendPort_textBox.Location = new System.Drawing.Point(180, 50);
            this.SendPort_textBox.Name = "SendPort_textBox";
            this.SendPort_textBox.Size = new System.Drawing.Size(69, 20);
            this.SendPort_textBox.TabIndex = 5;
            // 
            // IP_Address_textBox
            // 
            this.IP_Address_textBox.Location = new System.Drawing.Point(161, 24);
            this.IP_Address_textBox.Name = "IP_Address_textBox";
            this.IP_Address_textBox.Size = new System.Drawing.Size(107, 20);
            this.IP_Address_textBox.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(126, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "IP Address of Destination";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(23, 55);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "Port for Connecting";
            // 
            // redPictureBox
            // 
            this.redPictureBox.Image = global::WindowsFormsApplication7.Properties.Resources.hflvykipmc5g22mc3m0m;
            this.redPictureBox.Location = new System.Drawing.Point(345, 165);
            this.redPictureBox.Name = "redPictureBox";
            this.redPictureBox.Size = new System.Drawing.Size(152, 130);
            this.redPictureBox.TabIndex = 4;
            this.redPictureBox.TabStop = false;
            this.redPictureBox.Click += new System.EventHandler(this.redPictureBox_Click_1);
            // 
            // bluePictureBox
            // 
            this.bluePictureBox.Image = global::WindowsFormsApplication7.Properties.Resources.blue;
            this.bluePictureBox.Location = new System.Drawing.Point(181, 165);
            this.bluePictureBox.Name = "bluePictureBox";
            this.bluePictureBox.Size = new System.Drawing.Size(152, 130);
            this.bluePictureBox.TabIndex = 3;
            this.bluePictureBox.TabStop = false;
            this.bluePictureBox.Click += new System.EventHandler(this.bluePictureBox_Click_1);
            // 
            // greenPictureBox
            // 
            this.greenPictureBox.Image = global::WindowsFormsApplication7.Properties.Resources.darkGreenSquare;
            this.greenPictureBox.Location = new System.Drawing.Point(12, 165);
            this.greenPictureBox.Name = "greenPictureBox";
            this.greenPictureBox.Size = new System.Drawing.Size(152, 130);
            this.greenPictureBox.TabIndex = 1;
            this.greenPictureBox.TabStop = false;
            this.greenPictureBox.Click += new System.EventHandler(this.greenPictureBox_Click_1);
            // 
            // chosenpictureBox
            // 
            this.chosenpictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.chosenpictureBox.Location = new System.Drawing.Point(0, 0);
            this.chosenpictureBox.Name = "chosenpictureBox";
            this.chosenpictureBox.Size = new System.Drawing.Size(150, 150);
            this.chosenpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.chosenpictureBox.TabIndex = 13;
            this.chosenpictureBox.TabStop = false;
            // 
            // guessedpicturebox
            // 
            this.guessedpicturebox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.guessedpicturebox.Location = new System.Drawing.Point(0, 0);
            this.guessedpicturebox.Name = "guessedpicturebox";
            this.guessedpicturebox.Size = new System.Drawing.Size(152, 150);
            this.guessedpicturebox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guessedpicturebox.TabIndex = 6;
            this.guessedpicturebox.TabStop = false;
            // 
            // panelPlayer
            // 
            this.panelPlayer.Controls.Add(this.chosenpictureBox);
            this.panelPlayer.Location = new System.Drawing.Point(14, 326);
            this.panelPlayer.Name = "panelPlayer";
            this.panelPlayer.Size = new System.Drawing.Size(150, 150);
            this.panelPlayer.TabIndex = 14;
            // 
            // panelComputer
            // 
            this.panelComputer.Controls.Add(this.guessedpicturebox);
            this.panelComputer.Location = new System.Drawing.Point(354, 326);
            this.panelComputer.Name = "panelComputer";
            this.panelComputer.Size = new System.Drawing.Size(152, 150);
            this.panelComputer.TabIndex = 15;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(14, 482);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(141, 37);
            this.button1.TabIndex = 11;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(356, 483);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(141, 37);
            this.button2.TabIndex = 17;
            this.button2.Text = "Clear";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(190, 326);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(143, 160);
            this.listBox1.TabIndex = 18;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(249, 310);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 13);
            this.label8.TabIndex = 19;
            this.label8.Text = "label8";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 532);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panelComputer);
            this.Controls.Add(this.panelPlayer);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.redPictureBox);
            this.Controls.Add(this.bluePictureBox);
            this.Controls.Add(this.greenPictureBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.redPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bluePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.greenPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chosenpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guessedpicturebox)).EndInit();
            this.panelPlayer.ResumeLayout(false);
            this.panelComputer.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox greenPictureBox;
        private System.Windows.Forms.PictureBox bluePictureBox;
        private System.Windows.Forms.PictureBox redPictureBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button CloseConnection_button;
        private System.Windows.Forms.Button Connect_button;
        private System.Windows.Forms.TextBox SendPort_textBox;
        private System.Windows.Forms.TextBox IP_Address_textBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox chosenpictureBox;
        private System.Windows.Forms.PictureBox guessedpicturebox;
        private System.Windows.Forms.Panel panelPlayer;
        private System.Windows.Forms.Panel panelComputer;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label8;
    }
}

