﻿namespace WindowsFormsApplication7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.rockPicturebox = new System.Windows.Forms.PictureBox();
            this.paperPicturebox = new System.Windows.Forms.PictureBox();
            this.scissorsPictureBox = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.winnerLabel = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.PlayerPictureBox = new System.Windows.Forms.PictureBox();
            this.panelPlayer = new System.Windows.Forms.Panel();
            this.panelComputer = new System.Windows.Forms.Panel();
            this.computerpicturebox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.rockPicturebox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.paperPicturebox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.scissorsPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerPictureBox)).BeginInit();
            this.panelPlayer.SuspendLayout();
            this.panelComputer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.computerpicturebox)).BeginInit();
            this.SuspendLayout();
            // 
            // rockPicturebox
            // 
            this.rockPicturebox.Image = ((System.Drawing.Image)(resources.GetObject("rockPicturebox.Image")));
            this.rockPicturebox.Location = new System.Drawing.Point(21, 25);
            this.rockPicturebox.Name = "rockPicturebox";
            this.rockPicturebox.Size = new System.Drawing.Size(153, 130);
            this.rockPicturebox.TabIndex = 1;
            this.rockPicturebox.TabStop = false;
            this.rockPicturebox.Click += new System.EventHandler(this.rockPicturebox_Click);
            // 
            // paperPicturebox
            // 
            this.paperPicturebox.Image = ((System.Drawing.Image)(resources.GetObject("paperPicturebox.Image")));
            this.paperPicturebox.Location = new System.Drawing.Point(197, 25);
            this.paperPicturebox.Name = "paperPicturebox";
            this.paperPicturebox.Size = new System.Drawing.Size(130, 115);
            this.paperPicturebox.TabIndex = 3;
            this.paperPicturebox.TabStop = false;
            this.paperPicturebox.Click += new System.EventHandler(this.paperPicturebox_Click);
            // 
            // scissorsPictureBox
            // 
            this.scissorsPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("scissorsPictureBox.Image")));
            this.scissorsPictureBox.Location = new System.Drawing.Point(368, 25);
            this.scissorsPictureBox.Name = "scissorsPictureBox";
            this.scissorsPictureBox.Size = new System.Drawing.Size(149, 115);
            this.scissorsPictureBox.TabIndex = 4;
            this.scissorsPictureBox.TabStop = false;
            this.scissorsPictureBox.Click += new System.EventHandler(this.scissorsPictureBox_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(73, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Rock";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(234, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "paper";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(410, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "scissors";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(64, 335);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Player 1 Choice";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(397, 346);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Player 2 Choice";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(197, 325);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 10;
            this.btnClear.Tag = "";
            this.btnClear.Text = "clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // winnerLabel
            // 
            this.winnerLabel.Font = new System.Drawing.Font("Modern No. 20", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.winnerLabel.ForeColor = System.Drawing.Color.OrangeRed;
            this.winnerLabel.Location = new System.Drawing.Point(350, 372);
            this.winnerLabel.Name = "winnerLabel";
            this.winnerLabel.Size = new System.Drawing.Size(464, 20);
            this.winnerLabel.TabIndex = 11;
            this.winnerLabel.Text = "................................";
            this.winnerLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(629, 45);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(120, 95);
            this.listBox1.TabIndex = 12;
            // 
            // PlayerPictureBox
            // 
            this.PlayerPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PlayerPictureBox.Location = new System.Drawing.Point(14, 16);
            this.PlayerPictureBox.Name = "PlayerPictureBox";
            this.PlayerPictureBox.Size = new System.Drawing.Size(119, 120);
            this.PlayerPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PlayerPictureBox.TabIndex = 13;
            this.PlayerPictureBox.TabStop = false;
            // 
            // panelPlayer
            // 
            this.panelPlayer.Controls.Add(this.PlayerPictureBox);
            this.panelPlayer.Location = new System.Drawing.Point(41, 174);
            this.panelPlayer.Name = "panelPlayer";
            this.panelPlayer.Size = new System.Drawing.Size(150, 150);
            this.panelPlayer.TabIndex = 14;
            // 
            // panelComputer
            // 
            this.panelComputer.Controls.Add(this.computerpicturebox);
            this.panelComputer.Location = new System.Drawing.Point(368, 171);
            this.panelComputer.Name = "panelComputer";
            this.panelComputer.Size = new System.Drawing.Size(155, 150);
            this.panelComputer.TabIndex = 15;
            // 
            // computerpicturebox
            // 
            this.computerpicturebox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.computerpicturebox.Location = new System.Drawing.Point(17, 13);
            this.computerpicturebox.Name = "computerpicturebox";
            this.computerpicturebox.Size = new System.Drawing.Size(119, 120);
            this.computerpicturebox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.computerpicturebox.TabIndex = 6;
            this.computerpicturebox.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(826, 401);
            this.Controls.Add(this.panelComputer);
            this.Controls.Add(this.panelPlayer);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.winnerLabel);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.scissorsPictureBox);
            this.Controls.Add(this.paperPicturebox);
            this.Controls.Add(this.rockPicturebox);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.rockPicturebox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.paperPicturebox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.scissorsPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerPictureBox)).EndInit();
            this.panelPlayer.ResumeLayout(false);
            this.panelComputer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.computerpicturebox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox rockPicturebox;
        private System.Windows.Forms.PictureBox paperPicturebox;
        private System.Windows.Forms.PictureBox scissorsPictureBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label winnerLabel;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.PictureBox PlayerPictureBox;
        private System.Windows.Forms.Panel panelPlayer;
        private System.Windows.Forms.Panel panelComputer;
        private System.Windows.Forms.PictureBox computerpicturebox;
    }
}

