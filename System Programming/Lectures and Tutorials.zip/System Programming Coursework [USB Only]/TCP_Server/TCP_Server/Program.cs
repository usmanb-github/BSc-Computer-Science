﻿/*	File			Program.cs
	Purpose			TCP Server example for demonstration purposes
	Author			Richard Anthony	(R.J.Anthony@gre.ac.uk)
	Date			December 2011
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace TCP_Server
{
    static class Program
    {
        // The main entry point for the application.
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new TCP_Server_Form());
        }
    }
}
