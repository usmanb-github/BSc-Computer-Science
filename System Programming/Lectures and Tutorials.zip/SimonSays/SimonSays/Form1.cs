﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimonSays
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int onInList = 0;
        List<int> pattern = new List<int>();
        Random rand = new Random();
        bool playingBack = false;

        private void Red_Click(object sender, EventArgs e)
        {
            testCorrect(0);
        }

        private void Blue_Click(object sender, EventArgs e)
        {
            testCorrect(1);
        }

        private void Yellow_Click(object sender, EventArgs e)
        {
            testCorrect(2);
        }

        private void Green_Click(object sender, EventArgs e)
        {
            testCorrect(3);
        }
        void testCorrect(int colour)
        {
            if (playingBack)
            {
                return;
            }
            if(pattern[onInList] == colour)
            {
                onInList++;
            } else
            {
                MessageBox.Show("You fail! Final score: " + pattern.Count.ToString());
                onInList = 0;
                pattern = new List<int>();
                new Thread(playBack).Start();
            }
            if (onInList >= pattern.Count)
            {
                pattern.Add(rand.Next(0, 4));
                onInList = 0;
                new Thread(playBack).Start();
            }
            ScoreLabel.Text = ("Score: " + pattern.Count.ToString());
            PatternLabel.Text = ("Item within pattern: " + onInList.ToString());

        }
        void playBack()
        {
            playingBack = true;
            foreach (int colour in pattern)
            {
                switch (colour)
                {
                    case 0:
                        Red.BackColor = Color.Red;
                        Thread.Sleep(200);
                        Red.BackColor = Color.Transparent;
                        break;
                    case 1:
                        Blue.BackColor = Color.Blue;
                        Thread.Sleep(200);
                        Blue.BackColor = Color.Transparent;
                        break;
                    case 2:
                        Yellow.BackColor = Color.Yellow;
                        Thread.Sleep(200);
                        Yellow.BackColor = Color.Transparent;
                        break;
                    case 3:
                        Green.BackColor = Color.Green;
                        Thread.Sleep(200);
                        Green.BackColor = Color.Transparent;
                        break;
                }
                Thread.Sleep(200);
            }
            playingBack = false;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            pattern.Add(rand.Next(0, 4));
            new Thread(playBack).Start();
        }
    }
}
