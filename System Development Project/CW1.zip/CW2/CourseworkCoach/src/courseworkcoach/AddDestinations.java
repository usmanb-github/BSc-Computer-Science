package courseworkcoach;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.event.ActionEvent;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author ub2232e
 */
public class AddDestinations extends JFrame implements ActionListener {

    JTextField name = new JTextField(7);
    JTextField price = new JTextField(7);
    JTextField seats = new JTextField(7);
    JButton add = new JButton("Add");
   // JButton upload = new JButton("Browse");
    JLabel jLabel_Image = new JLabel();
    String filename;
    int s = 0;
    byte[] person_image = null;

    public AddDestinations() {
        setLayout(new BorderLayout());
        setBounds(100, 100, 700, 160);
        setTitle("Adding new Stock");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBackground(Color.blue);
        JPanel middle = new JPanel();
        middle.add(new JLabel("Name:"));
        middle.add(name);
        middle.add(new JLabel("Price:"));
        middle.add(price);
        middle.add(new JLabel("Seats:"));
        middle.add(seats);
        middle.add(jLabel_Image);
        middle.add(new JLabel("Upload Image:"));
     //   middle.add(upload);
       // upload.addActionListener(this);
        middle.add(add);
        add.addActionListener(this);
        add("Center", middle);
        setResizable(false);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (price.getText().isEmpty()) {
            Model.display("Please fill in the empty boxes to continue");
        } else if (e.getSource() == add) {
            try {
                Connection con = DriverManager.getConnection(Model.Host(), Model.User(), Model.Pass());
                PreparedStatement stmt = (PreparedStatement) con.prepareStatement("INSERT INTO STOCK(NAME, PRICE, SEATS, IMAGES) "
                        + "VALUES(?,?,?,?)");
                String nameStr = name.getText();
                double priceDouble = Double.parseDouble(price.getText());
                int seatsInt = Integer.parseInt(seats.getText());

                stmt.setString(1, nameStr);
                stmt.setDouble(2, priceDouble);
                stmt.setInt(3, seatsInt);
                stmt.setBytes(4, person_image);
                stmt.executeUpdate();
                Model.display("You have successfully added a new item");

                name.setText("");
                price.setText("");
                seats.setText("");

            } catch (Exception ea) {
                Model.display("" + ea);
            }
//        } else if (e.getSource() == upload) {
//            JFileChooser choose = new JFileChooser();
//            choose.showOpenDialog(null);
//            File f = choose.getSelectedFile();
//            filename = f.getAbsolutePath();
//            Image icon = new ImageIcon(filename).getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
//            ImageIcon imageIcon = new ImageIcon(icon);
//            jLabel_Image.setIcon(imageIcon);
//
//            try {
//                File image = new File(filename);
//                FileInputStream fis = new FileInputStream(image);
//                ByteArrayOutputStream bos = new ByteArrayOutputStream();
//                byte[] buf = new byte[1024];
//                for (int readNum; (readNum = fis.read(buf)) != -1;) {
//                    bos.write(buf, 0, readNum);
//
//                }
//                person_image = bos.toByteArray();
//            } catch (Exception ea) {
//                Model.display("" + ea);
//            }
        }
    }
}
