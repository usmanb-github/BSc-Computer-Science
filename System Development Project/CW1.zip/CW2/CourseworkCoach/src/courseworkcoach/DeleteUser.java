package courseworkcoach;

import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.text.DecimalFormat;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 *
 * @author ub2232e
 */
public class DeleteUser extends JFrame implements ActionListener {


JTextField stockNo = new JTextField(7);
    JButton checkBtn = new JButton("Check Stock");
    JButton deleteBtn = new JButton("Delete");
    DecimalFormat pounds = new DecimalFormat("£#,##0.00");
    JTextArea information = new JTextArea(10, 25);
    
    public DeleteUser() {
        setLayout(new BorderLayout());
        setBounds(200, 200, 600, 150);
        setTitle("Update Delete");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        JPanel top = new JPanel();
        top.add(new JLabel("Enter Destination:"));
        top.add(stockNo);
        top.add(checkBtn);
        checkBtn.addActionListener(this);
        add("North", top);
        JPanel middle = new JPanel();
        middle.add(information);
        add("Center", middle);
        JPanel bottom = new JPanel();
        bottom.add(deleteBtn);
        deleteBtn.addActionListener(this);
        add("South", bottom);
        setResizable(true);
        setVisible(true);
    }

    @Override
        public void actionPerformed(ActionEvent e) {
        String key = stockNo.getText();
        String name = Model.getUsername(key);

        if (name == null) {
            information.setText("No such item in stock");
        } else {
            information.setText("Username: " + name);
            information.append("\nPassword: " + Model.getPassword(key));
            information.append("\nName: " + Model.getNameLogin(key));
            information.append("\nSurname: " + Model.getSurname(key));
        }

        if (e.getSource() == deleteBtn) {
            if (name != null) {
                int confirmOption = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this item?");
                if (confirmOption == JOptionPane.YES_OPTION) {
                    try {
                        Connection con = DriverManager.getConnection(Model.Host(), Model.User(), Model.Pass());
                        Statement stmt = con.createStatement();
                        String sql = "DELETE FROM Login WHERE USERNAME = '" + key + "'";
                        stmt.execute(sql);
                        information.setText(name + " " + "deleted");
                    } catch (Exception ea) {
                        System.out.println(ea);
                    }
                }
                if (confirmOption == JOptionPane.NO_OPTION) {
                    Model.display("The action cannot be completed. Please try again.");
                }
            }
        }
}
}
