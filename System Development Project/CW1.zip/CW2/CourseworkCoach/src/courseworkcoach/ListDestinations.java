package courseworkcoach;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javafx.beans.property.SimpleBooleanProperty;
import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class ListDestinations extends JFrame implements ActionListener {

    DefaultTableModel model = new DefaultTableModel(new String[]{"NAME", "PRICE"}, 0);
    JTable table = new JTable();
    JScrollPane scroll = new JScrollPane(table);
    JButton view = new JButton("View");

    public static void main(String[] args) {
        new ListDestinations();
    }

    public ListDestinations() {
        setLayout(new BorderLayout());
        setSize(400, 350);
        setTitle("List Destinations");
        JPanel middle = new JPanel();
         scroll = new JScrollPane(table);
        scroll.setPreferredSize(new Dimension(300, 300));
        middle.add(scroll);
        add("Center", middle);
        JPanel bottom = new JPanel();
        bottom.add(view);
        view.addActionListener(this);
        add("South", bottom);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            Connection con = DriverManager.getConnection(Model.Host(), Model.User(), Model.Pass());
            Statement stmt = con.createStatement();
            String sql = "SELECT NAME, PRICE FROM STOCK";
            ResultSet rs = stmt.executeQuery(sql);

            //    ResultSetMetaData metadata = resultSet.getMetaData();
            //  int columnCount = metadata.getColumnCount();
            while (rs.next()) {
                String d = rs.getString("NAME");
                String f = rs.getString("PRICE");
                model.addRow(new Object[]{d, f});
            }
            table.setModel(model);
        } catch (SQLException ea) {

        }
         ((AbstractButton)e.getSource()).setEnabled(false);
    }
}
