package courseworkcoach;

import java.sql.*;
import java.io.*;
import javax.swing.JOptionPane;
import org.apache.derby.drda.NetworkServerControl;
/**
 *
 * @author ub2232e
 */
public class Model {

    private static Connection connection;
    private static Statement stmt;

    static {
        // standard code to open a connection and statement to an Access database
        try {
            NetworkServerControl server = new NetworkServerControl();
            server.start(null);
            // Load JDBC driver
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
            //Establish a connection
            String sourceURL = "jdbc:derby://localhost:1527/"
                    + new File("UserDB").getAbsolutePath() + ";";
            Connection UserDB = DriverManager.getConnection(sourceURL, "use", "pass");
            stmt = UserDB.createStatement();
        } catch (ClassNotFoundException cnfe) {
            System.out.println(cnfe);
        } catch (SQLException sqle) {
            System.out.println(sqle);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static String getName(String key) {
        try {
            ResultSet res = stmt.executeQuery("SELECT * FROM Stock WHERE NAME = '" + key + "'");
            if (res.next()) {
                return res.getString(1);
            } else {
                return null;
            }

        } catch (SQLException e) {
            System.out.println(e);
            return null;
        }
    }

    public static double getPrice(String key) {
        try {
            ResultSet rs = stmt.executeQuery("SELECT * FROM Stock WHERE NAME = '" + key + "'");
            if (rs.next()) {
                return rs.getDouble(2);
            } else {
                return -1.0;
            }
        } catch (SQLException ex) {
            System.out.println(ex);
            return -1.0;
        }
    }

    public static int getSeats(String key) {
        try {
            ResultSet rs = stmt.executeQuery("SELECT * FROM Stock WHERE NAME = '" + key + "'");
            if (rs.next()) {
                return rs.getInt(3);
            } else {
                return -1;
            }
        } catch (SQLException ex) {
            System.out.println(ex);
            return -1;
        }
    }

    public static void seatUpdate(String key, int extra) {
        String updateStr = "UPDATE Stock SET SEATS = SEATS + " + extra + " WHERE NAME = '" + key + "'";
        System.out.println("Updated");
        try {
            stmt.executeUpdate(updateStr);
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    public static void priceUpdate(String key, double extra) {
        String updateStr = "UPDATE Stock SET PRICE = PRICE + " + extra + " WHERE NAME = '" + key + "'";
        System.out.println("Updated");
        try {
            stmt.executeUpdate(updateStr);
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    //Login
    public static String getUsername(String key) {
        try {

            ResultSet res = stmt.executeQuery("SELECT * FROM Login WHERE USERNAME = '" + key + "'");
            if (res.next()) {

                return res.getString(1);
            } else {
                return null;
            }

        } catch (SQLException e) {
            System.out.println(e);
            return null;
        }
    }

    public static String getPassword(String key) {
        try {

            ResultSet res = stmt.executeQuery("SELECT * FROM Login WHERE USERNAME = '" + key + "'");
            if (res.next()) {
                return res.getString(2);
            } else {
                return null;
            }

        } catch (SQLException e) {
            System.out.println(e);
            return null;
        }
    }
      public static String getEmail(String key) {
        try {

            ResultSet res = stmt.executeQuery("SELECT * FROM Login WHERE USERNAME = '" + key + "'");
            if (res.next()) {
                return res.getString(5);
            } else {
                return null;
            }

        } catch (SQLException e) {
            System.out.println(e);
            return null;
        }
    }

    public static String getNameLogin(String key) {
        try {

            ResultSet res = stmt.executeQuery("SELECT * FROM Login WHERE USERNAME = '" + key + "'");
            if (res.next()) {
                return res.getString(3);
            } else {
                return null;
            }

        } catch (SQLException e) {
            System.out.println(e);
            return null;
        }
    }

    public static String getSurname(String key) {
        try {

            ResultSet res = stmt.executeQuery("SELECT * FROM Login WHERE USERNAME = '" + key + "'");
            if (res.next()) {
                return res.getString(4);
            } else {
                return null;
            }

        } catch (SQLException e) {
            System.out.println(e);
            return null;
        }
    }

    // close the database
    public static void close() {
        try {
            connection.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    public static void display(String s) {
        JOptionPane.showMessageDialog(null, s);
        //uses method to shorten code
    }

    public static String Host() {
        String host = "jdbc:derby://localhost:1527/UserDB";
        return host;
    }

    public static String User() {
        String user = "use";
        return user;
    }

    public static String Pass() {
        String pass = "pass";
        return pass;
    }
    //Login
    public static String getUsernameStaff(String key) {
        try {

            ResultSet res = stmt.executeQuery("SELECT * FROM STAFF WHERE USERNAME = '" + key + "'");
            if (res.next()) {

                return res.getString(1);
            } else {
                return null;
            }

        } catch (SQLException e) {
            System.out.println(e);
            return null;
        }
    }

    public static String getPasswordStaff(String key) {
        try {

            ResultSet res = stmt.executeQuery("SELECT * FROM STAFF WHERE USERNAME = '" + key + "'");
            if (res.next()) {
                return res.getString(2);
            } else {
                return null;
            }

        } catch (SQLException e) {
            System.out.println(e);
            return null;
        }
    }

    public static String getNameInfo(String key) {
        try {

            ResultSet res = stmt.executeQuery("SELECT * FROM Login WHERE USERNAME = '" + key + "'");
            if (res.next()) {
                return res.getString(3);
            } else {
                return null;
            }

        } catch (SQLException e) {
            System.out.println(e);
            return null;
        }
    }
}