package courseworkcoach;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
/**
 *
 * @author ub2232e
 */
public class NewPassword extends JFrame implements ActionListener {

    JPasswordField oldpassword = new JPasswordField(7);
    JPasswordField newpassword = new JPasswordField(7);
    JButton submit = new JButton("View");

    public NewPassword() {
        setLayout(new BorderLayout());
        setSize(450, 100);
        setTitle("Password Reset");
        JPanel top = new JPanel();
        top.add(new JLabel("Old Password"));
        top.add(oldpassword);
        oldpassword.addActionListener(this);
        top.add(new JLabel("New Password"));
        top.add(newpassword);
        newpassword.addActionListener(this);
        top.add(submit);
        submit.addActionListener(this);
        add("North", top);
        setLocationRelativeTo(null);
        setResizable(true);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String usernameStr = Login.getUsername();
        String newPasswordStr = newpassword.getText();
        if (e.getSource() == submit) {
                try {
                    Connection con = DriverManager.getConnection(Model.Host(), Model.User(), Model.Pass());
                    PreparedStatement stmt = (PreparedStatement) con.prepareStatement("UPDATE LOGIN SET PASSWORD = '" + newPasswordStr + "' WHERE USERNAME = '" + usernameStr + "'");
                    stmt.executeUpdate();
                    JOptionPane.showMessageDialog(null, "You have successfully updated your password.");

                } catch (Exception ea) {
                    Model.display("" + ea);
            }
        }
    }
}
