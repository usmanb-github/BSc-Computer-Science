package courseworkcoach;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.text.DecimalFormat;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class CheckStock extends JFrame implements ActionListener {

    TextArea information = new TextArea(4, 25);
    DecimalFormat pounds = new DecimalFormat("£#,##0.00");
    JLabel imageLabel = new JLabel(new ImageIcon("images.empty.jpg"));
    JFormattedTextField cardNumber = new JFormattedTextField(new DecimalFormat());
    JTextField cardName = new JTextField(7);
    JFormattedTextField expiryDate = new JFormattedTextField(new DecimalFormat());
    JFormattedTextField CVVCode = new JFormattedTextField(new DecimalFormat());
    JButton submit = new JButton("Submit");
    JTextField stockField = new JTextField(7);
    JFormattedTextField numberField = new JFormattedTextField(new DecimalFormat());
    String[] list = {"", "Window Seats", "Adjoined Seats", "Aisle Seats"};
    JComboBox comboBox = new JComboBox(list);
    JButton checkout = new JButton("Check Out");
    JButton cancel = new JButton("Cancel");
    JButton remove = new JButton("Remove");
    JButton continueShopping = new JButton("Continue Shopping");
    JButton check = new JButton("Check");
    JButton addToBasket = new JButton("Add To Basket");
    JButton purchase = new JButton("Purchase");
    double cost = 0.0;
    JTable table = new JTable();
    DefaultTableModel model = new DefaultTableModel();
    Object[] columns = {"Name", "Price", "Quantity", "Seat Preference"};
    JFrame gui = new JFrame();
    JFrame frame = new JFrame();
    JFrame gf = new JFrame();
    JLabel label = new JLabel("Test text");
    
    public CheckStock() {
//first frame
        frame.setLayout(new BorderLayout());
        frame.setBounds(100, 100, 800, 200);
        frame.setTitle("Check Stock");
        JPanel top = new JPanel();
        top.add(new JLabel("Enter Destination:"));
        top.add(stockField);
        top.add(check);
        check.addActionListener(this);
        top.add(new JLabel("How many: "));
        top.add(numberField);
        numberField.setValue(new Double(0));
        numberField.setColumns(5);
        top.add(new JLabel("           Preference: "));
        comboBox.setSelectedIndex(1);
        comboBox.addActionListener(this);
        top.add(comboBox);
        top.add(addToBasket);
        addToBasket.addActionListener(this);
        frame.add("North", top);
        JPanel middle = new JPanel();
        middle.add(information);
        middle.setLayout(new FlowLayout(FlowLayout.CENTER));
        frame.add("Center", middle);
        JPanel bottom = new JPanel();
        bottom.add(checkout);
        checkout.addActionListener(this);
        bottom.add(cancel, BorderLayout.WEST);
        cancel.addActionListener(this);
        frame.add("South", bottom);
        frame.setResizable(false);
        frame.setVisible(true);
//second frame
        gui.setLayout(new BorderLayout());
        gui.setBounds(100, 100, 700, 200);
        gui.setTitle("Purchase Item");
        setDefaultCloseOperation(gui.DISPOSE_ON_CLOSE);
        JPanel top1 = new JPanel();
        gui.add("North", top1);
        JPanel middle1 = new JPanel();
        model.setColumnIdentifiers(columns);
        table.setModel(model);
        table.setBackground(Color.LIGHT_GRAY);
        table.setForeground(Color.black);
        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(0, 0, 700, 200);
        middle1.add(pane);
        gui.add("Center", middle1);
        JPanel bottom1 = new JPanel();
        bottom1.add(continueShopping);
        continueShopping.addActionListener(this);
        bottom1.add(remove);
        remove.addActionListener(this);
        bottom1.add(purchase);
        purchase.addActionListener(this);
        gui.add("South", bottom1);
        gui.setResizable(false);
        gui.setVisible(false);
//third frame
        gf.setLayout(new BorderLayout());
        gf.setBounds(100, 100, 800, 90);
        setDefaultCloseOperation(gf.DISPOSE_ON_CLOSE);
        JPanel top2 = new JPanel();
        gf.setTitle("Credit Card Details");
        top2.add(new JLabel("Credit Card Name"));
        top2.add(cardName);
        top2.add(new JLabel("Credit Card Number"));
        top2.add(cardNumber);
        top2.add(new JLabel("Expiry Date"));
        top2.add(expiryDate);
        top2.add(new JLabel("CVV Code"));
        top2.add(CVVCode);
        cardNumber.setValue(0);
        cardNumber.setColumns(7);
        expiryDate.setValue(0);
        expiryDate.setColumns(7);
        CVVCode.setValue(0);
        CVVCode.setColumns(7);
        gf.add("North", top2);
        JPanel bottom2 = new JPanel();
        bottom2.add(submit);
        submit.addActionListener(this);
        gf.add("South", bottom2);
        gf.setResizable(false);
        gf.setVisible(false);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        String key = stockField.getText();
        String name = Model.getName(key);
        int numberOfItems = Integer.parseInt(numberField.getText());
        double cost = numberOfItems * Model.getPrice(key);
        Object[] row = new Object[5];

        if (name == null) {
            information.setText("No such item in stock");
        } else if (e.getSource() == check) {
            information.setText(name);
            information.append("\nPrice: " + pounds.format(Model.getPrice(key)));
            information.append("\nSeats: " + Model.getSeats(key));
        }
        if (numberOfItems < 0) {
            Model.display("Please type in how many seats you want!");
        } else if (e.getSource() == addToBasket) {
            if (numberOfItems <= Model.getSeats(key)) {
                information.append("\nSeats Selected:" + " " + "x" + " " + numberOfItems);
                this.cost += cost;
                information.append("\nSeats left:" + " " + (Model.getSeats(key) - numberOfItems));

                String msg = (String) comboBox.getSelectedItem();
                switch (msg) {
                    case "":
                        Model.display("Please select your preferred seat");
                        break;
                }

                row[0] = name;
                row[1] = cost;
                row[2] = numberOfItems;
                row[3] = msg;
                model.addRow(row);
                Model.display("Added to the basket");
            } else {
                Model.display("Please type the correct amount of seats you need!");
                numberField.setText("");
            }
        }
        if (numberOfItems == 0 && name == null) {
            Model.display("Please complete the above to continue");
        } else if (e.getSource() == checkout) {
            gui.setVisible(true);
            frame.setVisible(false);
        }
        if (e.getSource() == continueShopping) {
            gui.setVisible(false);
            frame.setVisible(true);
        } else if (e.getSource() == remove) {
            int i = table.getSelectedRow();
            if (i >= 0) {
                model.removeRow(i);
            } else {
                Model.display("Please select the one you want to delete!");
            }
        } else if (e.getSource() == purchase) {
            gui.setVisible(false);
            frame.setVisible(false);
            gf.setVisible(true);
        }
        if (e.getSource() == submit) {
            double sum = 0;
            for (int i = 0; i < table.getRowCount(); i++) {
                sum = sum + Double.parseDouble(table.getValueAt(i, 1).toString());
            }
            double discount = sum * 0.15;
            sum = sum - discount;
            Model.seatUpdate(key, -numberOfItems);
            Model.display("Total Cost is:" + " " + pounds.format(sum));
        }
        if (e.getSource() == cancel) {
            System.exit(0);
        }
    }
}
