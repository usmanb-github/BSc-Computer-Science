package stock;
//import java.awt.*;

import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.event.ActionEvent;
import java.text.DecimalFormat;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 *
 * @author ub2232e
 */
public class UpdatePrice extends JFrame
        implements ActionListener {

    JTextField stockNo = new JTextField(7);
    JTextField plus = new JTextField(7);
    JTextField minus = new JTextField(7);
    JButton checkTwo = new JButton("Check Stock");
    JButton update = new JButton("Add");
    JButton updateTwo = new JButton("Minus");
    DecimalFormat pounds = new DecimalFormat("£#,##0.00");
    JTextArea information = new JTextArea(3, 25);

    public UpdatePrice() {
        setLayout(new BorderLayout());
        setBounds(200, 200, 550, 150);
        setTitle("Update Price");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel top = new JPanel();
        top.add(new JLabel("Enter Stock Number:"));
        top.add(stockNo);
        top.add(checkTwo);
        checkTwo.addActionListener(this);

        add("North", top);
        JPanel middle = new JPanel();
        middle.add(information);
        add("Center", middle);
        JPanel bottom = new JPanel();
        bottom.add(new JLabel("Increasing Price:"));
        bottom.add(plus);
         bottom.add(update);
        update.addActionListener(this);
        bottom.add(new JLabel("Decreasing Price:"));
        bottom.add(minus);
        bottom.add(updateTwo);
        updateTwo.addActionListener(this);

        add("South", bottom);
        setResizable(false);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String key = stockNo.getText();
        String name = StockData.getName(key);
        if (name == null) {
            information.setText("No such item in stock");
        } else {
            information.setText(name);
            information.append("\nPrice: " + pounds.format(StockData.getPrice(key)));
            information.append("\nQuantity: " + StockData.getQuantity(key));
        }
        if (e.getSource() == update) {
            information.setText(name);
            int plusInt = Integer.parseInt(plus.getText());
            StockData.priceUpdatePlus(key, plusInt);
            information.append("\nPrice: " + pounds.format(StockData.getPrice(key)));
        }
        if (e.getSource() == updateTwo) {
            information.setText(name);
            int minusInt = Integer.parseInt(minus.getText());
            StockData.priceUpdateMinus(key, -minusInt);
            information.append("\nPrice: " + pounds.format(StockData.getPrice(key)));

        }
    }
}
