package stock;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class TwoButtons extends JFrame implements ActionListener {

    JButton update = new JButton("Update Existing");
    JButton updateTwo = new JButton("Update New");

    public TwoButtons() {
        setLayout(new BorderLayout());
        setSize(360, 150);
        setTitle("Update");
        JPanel top = new JPanel();
        add("North", top);

        JPanel bottom = new JPanel();
        bottom.add(update);
        update.addActionListener(this);
        update.setPreferredSize(new Dimension(150, 100));
        bottom.add(updateTwo);
        updateTwo.addActionListener(this);
        updateTwo.setPreferredSize(new Dimension(150, 100));
        add("South", bottom);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == update) {
            ExistingButtons edit = new ExistingButtons();
            setVisible(false);
        } else if (e.getSource() == updateTwo) {
            newStock n = new newStock();
            setVisible(false);
        }
    }
}
