package stock;
//all imports that is ncessary for this class is included below

import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.io.File;
import java.text.DecimalFormat;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class CheckStock extends JFrame implements ActionListener {
    // extends JFrame is used and ActionLister is needed to 
    //implement any buttons, or textareas to listen out for

    JTextField stockNo = new JTextField(7);
    //new field for stock
    TextArea information = new TextArea(3, 25);
    //creating a new textarea 
    JButton check = new JButton("Check Stock");
    // creating a new button called "Check Stock"
    DecimalFormat pounds = new DecimalFormat("£#,##0.00");
    JLabel imageLab = new JLabel(new ImageIcon("images.empty.jpg"));
    
    public CheckStock() {
        setLayout(new BorderLayout());
        //new layout
        setBounds(100, 100, 600, 200);
        //window measurements
        setTitle("Check Stock");
        //title name at the top
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        JPanel top = new JPanel();
        top.add(new JLabel("Enter Stock Number:"));
        // adding label to the top and labelling the label
        top.add(stockNo);
        //adding textfield to the window
        top.add(check);
        //adding button to the window
        check.addActionListener(this);
        //listening out to the check button
        add("North", top);
        //adding all the new features to the top
        JPanel middle = new JPanel();
        middle.add(information);
        //adding textarea
        middle.add(imageLab);
        //adding label
        add("Center", middle);
        JPanel bottom = new JPanel();
        add("South", bottom);
        //adding textarea to the middle
        setResizable(false);
        //resizing the window cannot be resized
        setVisible(true);
        //set to true to make the whole window visible
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String key = stockNo.getText();
        String name = StockData.getName(key);

        if (name == null) {
            information.setText("No such item in stock");
            //if no stock data that is not recognised, the outcome would insert 
            //this statement within the textarea information
        } else {
            information.setText(name);
            information.append("\nPrice: " + pounds.format(StockData.getPrice(key)));
            information.append("\nQuantity: " + StockData.getQuantity(key));
            //or else, add these information once the stock right is recognised. 
            //Whatever is recognised is stored within StockData. 
            //An example is 01. Once this is inserted, all the information about 01 is inserted.
            //gets the image and uses it as a key to display it
            String image = "Images\\" + key + ".jpg";
            File imageFile = new File(image);
            if (!imageFile.exists()) {
                image = "Images\\empty.jpg";
            }
            imageLab.setIcon(new ImageIcon(image));
        }
    }
}
