package stock;

import javax.swing.JOptionPane;
import javax.swing.*;
import java.awt.BorderLayout;
import static java.awt.Color.white;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.io.File;
import java.text.DecimalFormat;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PurchaseItem extends JFrame implements ActionListener {

    JTextField stockNo = new JTextField(7);
    JTextField number = new JTextField(7);
    TextArea information = new TextArea(4, 70);
    JButton purchase = new JButton("Purchase");
    JButton check = new JButton("Check Stock");
    DecimalFormat pounds = new DecimalFormat("£#,##0.00");
    JComboBox drop = new JComboBox();
    double totalCost = 0.0;
    JLabel imageLab = new JLabel(new ImageIcon("images.empty.jpg"));

    public PurchaseItem() {
        setLayout(new BorderLayout());
        setBounds(100, 100, 700, 200);
        setTitle("Purchase Item");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        JPanel top = new JPanel();
        top.add(new JLabel("Item: "));
        top.add(stockNo);
        top.add(check);
        check.addActionListener(this);
        top.add(new JLabel("How many: "));
        top.add(number);
        top.add(purchase);
        purchase.addActionListener(this);
        add("North", top);
        JPanel middle = new JPanel();
        middle.add(information);
        middle.add(imageLab);
        add("Center", middle);
        JPanel bottom = new JPanel();
        add("South", bottom);

        setResizable(false);
        setVisible(true);

        //allows the user not to edit the textfield
        information.setEditable(false);
        information.setBackground(white);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String key = stockNo.getText();
        String name = StockData.getName(key);

        if (name == null) {
            information.setText("No such item in stock");
        }
            if (e.getSource() == check) {
                information.setText(name);
                information.append("\nPrice: " + pounds.format(StockData.getPrice(key)));
                information.append("\nNumber in stock: " + StockData.getQuantity(key));
                
                //uses key to add images
                String image = "Images\\" + key + ".jpg";
                File imageFile = new File(image);
                if (!imageFile.exists()) {
                    image = "Images\\empty.jpg";
                }
                imageLab.setIcon(new ImageIcon(image));
            }
            if (e.getSource() == purchase) {
                int numberOfItems = Integer.parseInt(number.getText());
                double cost = numberOfItems * StockData.getPrice(key);
                if (numberOfItems <= StockData.getQuantity(key)) {
                    information.append("\n" + name + " " + "x" + " " + numberOfItems);
                    StockData.update(key, -numberOfItems);
                    totalCost += cost;
                    information.append("\nNumber in Stock:" + StockData.getQuantity(key));
                    JOptionPane.showMessageDialog(null, "\nTotal cost will be:" + " " + pounds.format(totalCost));

                    information.append("\n");
                    information.append("\nYou have sucessfully purchased " + " " + name);
                } else {
                    JOptionPane.showMessageDialog(null, "Sorry, we are out of stock! Please, try later!");
                }
            }
            information.append("\n");
    }
}
//  int numberOfItems = Integer.parseInt(drop.getSelectedItem().toString());
//  top.add(new JLabel("Quantity:"));
//        top.add(drop);
//        drop.addItem(1);
//        drop.addItem(2);
//        drop.addItem(3);
//        drop.addItem(4);
//        drop.addItem(5);
//        drop.addItem(6);
//        drop.addItem(7);
//        drop.addItem(8);
//        drop.addItem(9);
//        drop.addItem(10);
