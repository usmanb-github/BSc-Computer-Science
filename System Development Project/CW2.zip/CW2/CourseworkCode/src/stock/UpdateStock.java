package stock;

import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.text.DecimalFormat;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author ub2232e
 */
public class UpdateStock extends JFrame
        implements ActionListener {

    JTextField stockNo = new JTextField(7);
    JTextField update = new JTextField(7);
    TextArea information = new TextArea(10, 50);
    JButton checkTwo = new JButton("Check Stock");
    JButton add = new JButton("Add");
    DecimalFormat pounds = new DecimalFormat("£#,##0.00");

    public UpdateStock() {
        setLayout(new BorderLayout());
        setBounds(200, 200, 700, 150);
        setTitle("Update Stock");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel top = new JPanel();
        top.add(new JLabel("Enter Stock Number:"));
        top.add(stockNo);
        top.add(checkTwo);
        checkTwo.addActionListener(this);
        top.add(new JLabel("Quantity:"));
        top.add(update);
        top.add(add);
        add.addActionListener(this);
        add("North", top);
        JPanel middle = new JPanel();
        middle.add(information);
        add("Center", middle);
        JPanel bottom = new JPanel();
        add("South", bottom);

        setResizable(false);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String key = stockNo.getText();
        String name = StockData.getName(key);

        if (name == null) {
            information.setText("No such item in stock");
        } else {
            information.setText(name);
            information.append("\nCurrently in Stock: " + StockData.getQuantity(key));
        }
        if (e.getSource() == add) {
            information.setText(name);
            int quantity = Integer.parseInt(update.getText());
            StockData.update(key, quantity);
            information.append("\nCurrently in Stock: " + StockData.getQuantity(key));
        }
    }
}    