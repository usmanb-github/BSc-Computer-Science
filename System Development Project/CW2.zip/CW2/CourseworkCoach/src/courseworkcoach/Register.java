package courseworkcoach;
//import java.awt.*;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.regex.Pattern;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;

/**
 *
 * @author ub2232e
 */
public class Register extends JFrame
        implements ActionListener {

    JTextField name = new JTextField(7);
    JTextField surname = new JTextField(7);
    JTextField username = new JTextField(7);
    JTextField email = new JTextField(10);
    JPasswordField password = new JPasswordField(7);
    JButton complete = new JButton("Already Registered?");
    JButton submit = new JButton("Submit");

    public static void main(String[] args) {
        Register object = new Register();
    }

    public Register() {
        setLayout(new BorderLayout());
        setBounds(100, 100, 800, 90);
        setTitle("Register");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBackground(Color.blue);
        JPanel top = new JPanel();
        top.add(new JLabel("Username:"));
        top.add(username);
        top.add(new JLabel("Password:"));
        top.add(password);
        top.add(new JLabel("Name:"));
        top.add(name);
        top.add(new JLabel("Surname:"));
        top.add(surname);
        top.add(new JLabel("Email:"));
        top.add(email);
        add("North", top);
        JPanel bottom = new JPanel();
        bottom.add(complete);
        complete.addActionListener(this);
        bottom.add(submit);
        submit.addActionListener(this);
        add("South", bottom);
        setResizable(false);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String usernameStr = username.getText();
        String passwordStr = password.getText();
        String nameStr = name.getText();
        String surnameStr = surname.getText();
        String emailStr = email.getText();

        if (e.getSource() == complete) {
            int confirmOption = JOptionPane.showConfirmDialog(null, "Are you sure have already registered?");
            if (confirmOption == JOptionPane.YES_OPTION) {
                Login object = new Login();
                setVisible(false);
            }
        } else if (e.getSource() == submit) {
            if (!(Pattern.matches("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                    + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$", emailStr))) {
                JOptionPane.showMessageDialog(null, "Please enter a valid email", "Error", JOptionPane.ERROR_MESSAGE);
            } else if (usernameStr.isEmpty() && passwordStr.isEmpty() && nameStr.isEmpty() && surnameStr.isEmpty() && emailStr.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill in the rest of details to register.");
            } else {
                try {
                    Connection con = DriverManager.getConnection(Model.Host(), Model.User(), Model.Pass());
                    PreparedStatement stmt = (PreparedStatement) con.prepareStatement("INSERT INTO LOGIN(USERNAME, PASSWORD, NAME, SURNAME, EMAIL) "
                            + "VALUES(?,?,?,?,?)");
                    stmt.setString(1, usernameStr);
                    stmt.setString(2, passwordStr);
                    stmt.setString(3, nameStr);
                    stmt.setString(4, surnameStr);
                    stmt.setString(5, emailStr);
                    stmt.executeUpdate();
                    JOptionPane.showMessageDialog(null, "You have successfully registered.");

                    name.setText("");
                    surname.setText("");
                    username.setText("");
                    password.setText("");
                    Login object = new Login();
                    setVisible(false);
                } catch (Exception ea) {
                    Model.display("The details you have entered do not match, please try again." + ea);
                }
            }
        }
    }
}
