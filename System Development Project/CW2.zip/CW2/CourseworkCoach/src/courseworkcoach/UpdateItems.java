package courseworkcoach;

import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.text.DecimalFormat;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author ub2232e
 */
public class UpdateItems extends JFrame
        implements ActionListener {

    JTextField stockNo = new JTextField(7);
    JTextField updateSeats = new JTextField(7);
    JTextField updatePrice = new JTextField(7);
    TextArea information = new TextArea(5, 40);
    JButton submit = new JButton("Check");
    JButton addSeats = new JButton("+");
    JButton addPrice = new JButton("+");
    JButton minusPrice = new JButton("-");
    DecimalFormat pounds = new DecimalFormat("£#,##0.00");
    
    public UpdateItems() {
        setLayout(new BorderLayout());
        setBounds(100, 100, 500, 200);
        setTitle("Update Stock");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        JPanel top = new JPanel();
        top.add(new JLabel("Enter Destination:"));
        top.add(stockNo);
        top.add(submit);
        submit.addActionListener(this);
        add("North", top);
        JPanel middle = new JPanel();
        middle.add(information);
        add("Center", middle);
        JPanel bottom = new JPanel();
        bottom.add(new JLabel("Seats:"));
        bottom.add(updateSeats);
        bottom.add(addSeats);
        addSeats.addActionListener(this);
        bottom.add(new JLabel("Price:"));
        bottom.add(updatePrice);
        bottom.add(addPrice);
        addPrice.addActionListener(this);
        bottom.add(minusPrice);
        minusPrice.addActionListener(this);
        add("South", bottom);
        setResizable(false);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String key = stockNo.getText();
        String name = Model.getName(key);

        if (name == null) {
            information.setText("No such item in stock");
        } else if (e.getSource() == submit) {
            information.setText(name);
            information.append("\nCurrently Seats Available: " + Model.getSeats(key));
            information.append("\nCurrent Price: " + pounds.format(Model.getPrice(key)));
        } else if (e.getSource() == addSeats) {
            information.setText(name);
            int seats = Integer.parseInt(updateSeats.getText());
            Model.seatUpdate(key, seats);
            information.append("\nCurrent Seats: " + Model.getSeats(key));
        } else if (e.getSource() == addPrice) {
            information.setText(name);
            double price = Integer.parseInt(updatePrice.getText());
            Model.priceUpdate(key, price);
            information.append("\nCurrent Price: " + pounds.format(Model.getPrice(key)));
        } else if (e.getSource() == minusPrice) {
            information.setText(name);
            double price = Integer.parseInt(updatePrice.getText());
            Model.priceUpdate(key, -price);
            information.append("\nCurrent Price: " + pounds.format(Model.getPrice(key)));
        }
    }
}
