package courseworkcoach;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Master extends JFrame implements ActionListener {

    JButton check = new JButton("Check Item");
    JButton list = new JButton("View Destinations");
    JButton stock = new JButton("Update Stock");
    JButton profile = new JButton("Customer Profile");
    JButton quit = new JButton("Exit");

    public static void main(String[] args) {
        Master master = new Master();
    }

    public Master() {
        setLayout(new BorderLayout());
        setSize(700, 100);
        setTitle("Master");
        JPanel top = new JPanel();
        top.add(new JLabel("Select an option by clicking one of the buttons below"));
        add("North", top);
        JPanel bottom = new JPanel();
        bottom.add(list);
        list.addActionListener(this);
        bottom.add(check);
        check.addActionListener(this);
        bottom.add(stock);
        stock.addActionListener(this);
        bottom.add(profile);
        profile.addActionListener(this);
        bottom.add(quit);
        quit.addActionListener(this);
        add("South", bottom);

        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == check) {
            CheckStock checkStock = new CheckStock();
        } else if (e.getSource() == list) {
            ListDestinations a = new ListDestinations();
        } else if (e.getSource() == stock) {
            LoginStaff obj4 = new LoginStaff();
            this.setVisible(false);
        } else if (e.getSource() == profile) {
            CustomerProfile obj5 = new CustomerProfile();
        }
    }
}
