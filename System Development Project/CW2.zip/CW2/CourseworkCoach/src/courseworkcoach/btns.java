package courseworkcoach;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author ub2232e
 */
public class btns extends JFrame implements ActionListener {

    JButton items = new JButton("Update Items");
    JButton user = new JButton("Delete User");
    JButton trip = new JButton("Delete Trip");
    JButton add = new JButton("Add Destinations");
    JButton back = new JButton("Back to Main");

    public btns() {
        setLayout(new BorderLayout());
        setSize(600, 80);
        setTitle("Choose the following:");
        JPanel top = new JPanel();
        add("North", top);
        JPanel bottom = new JPanel();
        bottom.add(items);
        items.addActionListener(this);
        bottom.add(user);
        user.addActionListener(this);
        bottom.add(trip);
        trip.addActionListener(this);
        bottom.add(add);
        add.addActionListener(this);
        bottom.add(back);
        back.addActionListener(this);
        add("South", bottom);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == items) {
            UpdateItems obj1 = new UpdateItems();
        } else if (e.getSource() == user) {
            DeleteUser obj2 = new DeleteUser();
        } else if (e.getSource() == trip) {
            DeleteTrip obj3 = new DeleteTrip();
        } else if (e.getSource() == add) {
            AddDestinations obj3 = new AddDestinations();
        } else if (e.getSource() == back) {
            Master obj4 = new Master();
            this.setVisible(false);
        }
    }
}
