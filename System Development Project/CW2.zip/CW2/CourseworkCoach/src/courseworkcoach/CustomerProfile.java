package courseworkcoach;

import java.awt.BorderLayout;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
/**
 *
 * @author ub2232e
 */
public class CustomerProfile extends JFrame implements ActionListener {

    TextArea information = new TextArea(15, 25);
    JButton submit = new JButton("View Details");
    JButton password = new JButton("Password");
   
    public CustomerProfile() {
        setLayout(new BorderLayout());
        setSize(350, 250);
        setTitle("Customer Profile");
        JPanel top = new JPanel();
        top.add(new JLabel("Customer Profile"));
        add("North", top);
        JPanel middle = new JPanel();
        middle.add(information);
        add("Center", middle);
        JPanel bottom = new JPanel();
        bottom.add(submit);
        submit.addActionListener(this);
        bottom.add(password);
        password.addActionListener(this);
        add("South", bottom);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String key = Login.getUsername();
        if (e.getSource() == submit) {
            information.append("Name: " + Model.getNameLogin(key));
            information.append("\nSurname: " + Model.getSurname(key));
            information.append("Username: " + key);
            information.append("Email: " + Model.getEmail(key));
        } else if (e.getSource() == password) {
            NewPassword pass = new NewPassword();
        }
    }
}
