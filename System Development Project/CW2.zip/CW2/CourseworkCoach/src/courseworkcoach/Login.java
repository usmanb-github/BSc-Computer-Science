package courseworkcoach;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Login extends JFrame implements ActionListener {

    public static JPasswordField password = new JPasswordField(7);
    public static JTextField username = new JTextField(7);
    JButton login = new JButton("Login");

    public Login() {
        setLayout(new BorderLayout());
        setSize(420, 70);
        setTitle("Login");
        JPanel top = new JPanel();
        top.add(new JLabel("Username: "));
        top.add(username);
        top.add(new JLabel("Password: "));
        top.add(password);
        top.add(login);
        login.addActionListener(this);
        add("North", top);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == login) {

            String z = username.getText();
            String i = password.getText();
            if (z.isEmpty() && i.isEmpty()) {
                Model.display("Please fill it in before continuting");
            } else if (z.matches(Model.getUsername(z)) && i.matches(Model.getPassword(z))) {
                Model.display("Welcome " + " " + Model.getNameLogin(z) + " " + Model.getSurname(z));
                Model.display("Login Successful!");
                setVisible(false);
                new Master();
            } else if (!(z.matches(Model.getUsername(z)) && i.matches(Model.getPassword(z)))) {
                Model.display("Wrong details entered, try again.");
            }
        }
    }

    public static String getUsername() {
        return username.getText();
    }

    public static String getPassword() {
        return password.getText();
    }
}
